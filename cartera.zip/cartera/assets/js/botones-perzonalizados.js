const dom = "<'row mb-4'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>" +
"<'row'<'col-sm-12'tr>>" +
"<'row'<'col-sm-5'i><'col-sm-7'p>>";
const buttons = [{
                //Botón para Excel
                extend: 'excelHtml5',
                footer: true, 
                //Aquí es donde generas el botón personalizado
                text: '<span class="badge bg-success"><i class="fas fa-file-excel"></i></span>',
                className: 'btn btn-success'
            },
            //Botón para PDF
            {
                extend: 'pdfHtml5',
                download: 'open',
                footer: true,
                text: '<span class="badge bg-danger"><i class="fas fa-file-pdf"></i></span>',
                className: 'btn btn-danger',
                exportOptions: {
                    columns: [0, ':visible']
                    
                }
            },
            //Botón para copiar
            // {
            //     extend: 'copyHtml5',
            //     footer: true,
            //     text: '<span class="badge bg-primary"><i class="fas fa-copy"></i></span>',
            //     exportOptions: {
            //         columns: [0, ':visible']
            //     }
            // },
            //Botón para print
            {
                extend: 'print',
                footer: true,
                text: '<span class="badge bg-dark"><i class="fas fa-print"></i></span>',
                className: 'btn btn-dark'
            },
            //Botón para cvs
            // {
            //     extend: 'csvHtml5',
            //     footer: true,
            //     text: '<span class="badge bg-success"><i class="fas fa-file-csv"></i></span>'
            // },
            {
                extend: 'colvis',
                text: '<span class="badge bg-info"><i class="fas fa-columns"></i></span>',
                postfixButtons: ['colvisRestore']
            }
        ]