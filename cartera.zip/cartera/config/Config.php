<?php
define('BASE_URL', 'http://localhost/APPITGEM/cartera/');
define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '');
define('DBNAME', 'sistema');
define('CHARSET', 'charset=utf8');
define('TITLE', 'Cartera ITGEM Corinto');
define('MONEDA', 'S/ ');
define('HOST_SMTP', 'smtp.gmail.com');
define('USER_SMTP', 'anndresbrown11@gmail.com');
define('CLAVE_SMTP', 'omejckiuzwfrnfcc');
define('PUERTO_SMTP', 465);
?>